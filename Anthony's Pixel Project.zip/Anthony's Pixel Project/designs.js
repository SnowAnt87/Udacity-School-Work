//initializers
//

const sizePicker = document.body.querySelector('#sizePicker');

const pixelCanvas = document.body.querySelector('#pixelCanvas');

const inputHeight = sizePicker.querySelector('#inputHeight');

const inputWidth = sizePicker.querySelector('#inputWidth');

const colorPicker = document.body.querySelector('#colorPicker');

let blank = true;

let oldHeight = 1;

let oldWidth = 1;


//functions
//

function addColor(e) {
	e.target.style.backgroundColor = colorPicker.value;
}


function makeGrid() {

	//remove old canvas, check if blank then nothing to remove
	if (!blank) {
		for (let rows = 0; rows < oldHeight; rows++) {
			let newRow = pixelCanvas.querySelector('tr');			
			for(let columns = 0; columns < oldWidth; columns++) {
				newRow.querySelector('td').removeEventListener('click', addColor);
				newRow.querySelector('td').remove();
			}
			newRow.remove();
		}	
	}
	
	//Save new state of canvas
	blank = false;
	oldHeight = inputHeight.value;
	oldWidth = inputWidth.value;

	//create Canvas
	pixelCanvas.setAttribute('style', 'border: 1px solid black; align: center; valign: bottom');	
	for (let rows = 0; rows < inputHeight.value; rows++) {
		let newRow = document.createElement('tr');
		newRow.setAttribute('style', 'height: 20px');
		let currentRow = pixelCanvas.appendChild(newRow);
		for (let columns = 0; columns < inputWidth.value; columns++) {
			let newColumn = document.createElement('td');
			newColumn.textContent = null;
			newColumn.setAttribute('style', 'width: 20px'); 
			currentRow.appendChild(newColumn);
			newColumn.addEventListener('click', addColor);
		}
	}
}

//events
//

sizePicker.addEventListener('submit', (e) => {
	if (inputHeight.value != 1 || inputWidth.value != 1) {
		e.preventDefault();
		makeGrid();
	}
});